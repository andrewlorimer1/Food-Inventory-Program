
import java.util.Scanner;

/**
 * This class runs the food inventory program by using methods in class
 * Inventory. Method displayMainMenu to print a menu system allowing the user to
 * manipulate an inventory system storing food items.
 * 
 * CET - CS Academic Level 3 Declaration: I declare that this is my own original
 * work and is free from Plagiarism
 * 
 * Student Name: Andrew Lorimer Student Number: 041056170 Section #: 301 Course:
 * CST8130 - Data Structures Professor: James Mwangi PhD.
 * 
 * @author Andrew Lorimer
 * @version 1.0
 * @since 1.8
 */

public class Assign2 {
	/**
	 * Stores case option for adding item
	 */
	final int ADD = 1;
	/**
	 * Stores case option for displaying current inventory
	 */
	final int DISPLAY = 2;

	/**
	 * Stores case option for buying item
	 */
	final int BUY = 3;

	/**
	 * Stores case option for selling
	 */
	final int SELL = 4;
	/**
	 * Stores case option for searching inventory for Item code
	 */
	final int SEARCH =5;
	/**
	 * Stores case option for saving the current inventory to txt file
	 */
	final int WRITE =6;
	/**
	 * Stores case option for reading in inventory contents
	 */
	final int READ=7;

	/**
	 * Store case option for exiting
	 */
	final int EXIT = 8;

	
	
	/**
	 * Main entry point for the program
	 * 
	 * @param args an array of command-line arguments for the program
	 */
	public static void main(String[] args) {
        
		Assign2 assign2 = new Assign2();
		assign2.showMenu();

	}

	/**
	 * method to display the menu system to the user
	 */
	public void showMenu() {
		boolean validOption = true;

        //create new instance of inventory to access its methods
		Inventory inventory = new Inventory();
		int option = 0;
		do {
			Scanner keyboard = new Scanner(System.in);

			System.out.println(
					"\n+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+");
			System.out.println("Please select one of the following");

			System.out.printf("\n%s Add Item to Inventory  %n", ADD);

			System.out.printf("%s Display Current Inventory %n", DISPLAY);

			System.out.printf("%s Buy Item(s) %n", BUY);

			System.out.printf("%s Sell Item (s) %n", SELL);
			
			System.out.printf("%s Search for Item (s) %n", SEARCH);
			
			System.out.printf("%s Save Inventory to File (s) %n", WRITE);
			
			System.out.printf("%s Read Inventory from File (s) %n", READ);

			System.out.printf("%s To Exit %n", EXIT);

			// trap user until input is valid

			do {
				try {
					validOption = true;
					option = keyboard.nextInt();

					if (option > 8 || option < 1) {
						throw new Exception();
					}
					// throw exception if input is not between 1-4
				} catch (Exception e) {

					System.out.println("Please enter a number between 1-8");
					validOption = false;
					keyboard.nextLine();
				}
			} while (validOption == false);

			switch (option) {
			// case for adding food items to inventory
			case ADD:
		        keyboard.nextLine();
				inventory.addItem(keyboard , false);
				break;
			// case for displaying the inventory
			case DISPLAY:
				System.out.println(inventory);
				break;
			// case for buying items
			case BUY:
				boolean valid = true;
				//if not valid print error message
				valid = inventory.updateQauntity(keyboard, true);
				if (valid == false) {
					System.out.println("Cannot buy item");
				}

				break;
			// case for selling food items from inventory
			case SELL:
            // if not valid print error message 
				valid = inventory.updateQauntity(keyboard, false);
				if (valid == false) {
					System.out.println("Cannot sell item");
				}
				break;
			//case for performing binary search on inventory 
			case SEARCH:
             inventory.searchForItem(keyboard);
				break;
		    //stores case for saving inventory to a file
			case WRITE:
				inventory.saveToFile(keyboard);
				break;
		   //stores case for reading in food items for a text file
			case READ:
				 inventory.readFromFile(keyboard);
				break;

           //case for exiting the menu 
			case EXIT:
				System.out.println("Exiting ");
				System.out.println("Program made by Andrew Lorimer");
				keyboard.close();
				break;
			//default case if none of the above cases were selected	
				default:
					System.out.println("Invalid response");
				}
        //loop until exit is selected
		} while (option != 8);

	}

}
